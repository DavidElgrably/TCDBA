
--create Auto Script for Create Table
USE [Northwind]
GO
CREATE TABLE  [Categories1](
	[CategoryID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryName] [nvarchar](15) NOT NULL,
	[Description] [ntext] NULL,
	[Picture] [image] NULL,
) ON [PRIMARY] 

GO
--Select into to Create Table
select * into #tttt
from Categories
where 2=3

--Create Table - Default Value 
create table  MyTable  
(id1 int not null default 12,
id2 int null default 13)

insert into MyTable values (default , default )

select * from MyTable

insert into mytable (id1, id2) values (50 , default)

insert into mytable   values (51 , default)
go 100

truncate table mytable 

drop table mytable

--Create Table - Identity Column
create table  MyTable  
(id1 int not null identity(10,1),
id2 int null default 13,
salary money default 7500)

insert into MyTable values (59, 8000)

insert into MyTable (id2 , salary) 
values (59, 8000)

drop table MyTable

--Create Table - Check Constraint - example 1 
create table  MyTable  
(id1 int not null identity(10,1),
id2 int null default 13,
salary money check(salary between 100000 and 500000) )

insert into mytable (id2 ) 
values (default , 50000)
 
 drop table  MyTable

 --Create Table - Check Constraint - example 2
 create table  MyTable  
(id1 int not null identity(10,1),
id2 int null default 13,
salary money check(salary between 100000 and 500000) default 100000 )

insert into mytable (id2, salary  ) 
values (default , null)


--Create Table - Check Constraint - example 3
 create table  MyTable  
(id1 int not null identity(10,1),
id2 int null default 13,
email varchar(100) check(email like '%@%' or email  like '%co.il' ) )

insert into MyTable values (default , 'moshe@technion.co.il')

select * from mytable 

--Create Table - Check Constraint - example 4
 create table  MyTable  
(id1 int not null identity(10,1),
id2 int null default 13,
title varchar(1) check(title in ('MASTER','PROF','MBA','DR')) )


insert into MyTable values (default , 'STAM')

insert into MyTable values (default , 'P')

insert into MyTable values (default , null)

truncate table mytable 



