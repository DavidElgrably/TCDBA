 

 -- Debug
 -- Condition
 -- Snippet
 -- Surround With
 --Code Snippets Manager
 --book-mark-window

DECLARE @x AS integer
DECLARE @y AS integer
DECLARE @z AS integer

SET @x = 1   SET @y = 7    SET @z = @x/@y
 
BEGIN TRY 
	 WHILE( @y > -7 )
		BEGIN
			SET @y = @y - 1
			set @z = @x/@y + 10 
			exec dudi @i = 4, @j = @y output

			if (@y = 10)
			break;

		END
END TRY
BEGIN CATCH
	THROW
END CATCH

 alter  proc dudi (   @i int  , @j int output  )
 as
 set @j  = 10 
 select * from Employees
 where EmployeeID = @i 
